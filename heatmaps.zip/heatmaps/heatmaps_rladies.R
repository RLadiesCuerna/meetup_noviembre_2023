#!/usr/bin/env Rscript
#  heatmpas_rladies.R
#  Copyright 20223- E. Ernestina Godoy Lozano (elizabeth.godoy@insp.mx)
#
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  Texto sin acentos

################################################
####          Creacion de Heatmaps          ####
####           rladies Cuernavaca           ####
####        E. Ernestina Godoy Lozano       ####
################################################

#########################################################
####           Instalar librerias de trabajo         ####
#########################################################

#install.packages("ggplot2")
#install.packages("gplots")
#install.packages("vegan")
#install.packages("reshape2")
#install.packages("circlize")
#if (!requireNamespace("BiocManager", quietly=TRUE))
#  install.packages("BiocManager")
#BiocManager::install("ComplexHeatmap")
#BiocManager::install("Heatplus")

#########################################################
####           Cargar librerias de trabajo           ####
#########################################################

library(gplots)
library(ggplot2)
library(vegan)
library(reshape2)
library(Heatplus)
library(ComplexHeatmap)
library(circlize)

# Texto sin acentos

# Posicionarme en mi espacio de trabajo
getwd()
dir()

#### leer los datos
## Leeremos una tabla transpuesta
tabla <- t(read.delim("tablas/percent_Class_more_1_perc.txt", 
                      header=T, row.names=1))

# Exploracion de datos
dim(tabla)
View(tabla)

### Ejercicio 1. heatmap basico
## Libreria stats; funcion: heatmap

colors <- colorRampPalette(c("lightyellow", "dodgerblue"), space="rgb")(100)
length(colors)
head(colors)

heatmap(tabla, Rowv=NA, Colv= NA, col= colors, margins= c(10,2))

### Ejercicio 2. Agrupaciones jerarquicas
# 1. Generar matriz de distancias de las muestras (filas)
mat_dist <- vegdist(tabla, method="bray")

# 2. Generar la clusterizacion jerarquica
row.clus <- hclust(mat_dist, "aver")

# 3. Integrarlo al heatmap
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= NA, col= colors, margins= c(10,3))

# 4. Generar la agrupacion de las columnas
mat_dist_class <- vegdist(t(tabla), method = "bray")
col.clus <- hclust(mat_dist_class, "aver")

# 5. Integrarlo al heatmap
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))

# 6. Generar la figura (png)
png("figuras/heatmap_class_basico.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap(tabla, Rowv=as.dendrogram(row.clus), 
        Colv= as.dendrogram(col.clus), col= colors, margins= c(12,3))
dev.off()

##### Ejercicio 3. Identificacion de clusters
## Libreria gplots; funcion: heatmap.2

View(tabla)
muestras <- data.frame(nombre=rownames(tabla))
head(muestras)
muestras
muestras$clase <- sapply(as.character(muestras$nombre), 
                         function(x){strsplit(x, "_")[[1]][1]})

muestras$color <- "#A71B4BFF"
muestras$color[which(muestras$clase=="Someras")] <- "#3E8853"
muestras$color[which(muestras$clase=="Profundas")] <- "#795FAF"


heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col="cm.colors", 
          RowSideColors= muestras$color, margins=c(6,3))

dev.off()

# Modifiquemoslo
heatmap.2(tabla, 
          Rowv = as.dendrogram(row.clus), # dendograma filas
          Colv=as.dendrogram(col.clus), # dendograma columnas
          col=colors, # Escala de colores
          RowSideColors=muestras$color, # colores de las filas
          margins=c(13,10),
          trace="none", # The distance of the line from the center of each color-cell is proportional to the size of the measuremen
          density.info = "none", # a 'density' plot, or no plot ('none') on the color-key
          key.title="Relative abundance", 
          xlab="Clase", ylab="Muestras", # Etiquetas
          main="Heatmap a nivel de Clase", 
          lhei = c(2,8)) # modificacion del tamaño del color key
legend("topright", c("Costa", "Profundas", "Someras"), # agregar leyenda
       fill=c("#A71B4BFF", "#795FAF", "#3E8853"))



png("figuras/heatmap_class_complejo.png", width = 300*10, height = 300*6, units = "px", res=300)
heatmap.2(tabla, Rowv = as.dendrogram(row.clus), 
          Colv=as.dendrogram(col.clus),
          col=colors, 
          RowSideColors=muestras$color, 
          margins=c(13,10),
          trace="none", density.info = "none", 
          xlab="Clase", ylab="Muestras",
          main="Heatmap a nivel de Clase", lhei = c(2,8))
legend("bottomleft", c("Costa", "Profundas", "Someras"), 
       fill=c("#A71B4BFF", "#795FAF", "#3E8853"))
dev.off()

#### Ejercicio 4. Agregar anotaciones de otras variables

variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names=1)
head(variables)

var_interes <- c("Naphthalene", "Fluorene", "Organic_Matter")
subtabla <- variables[,which(colnames(variables)%in% var_interes)]
head(subtabla)

head(muestras)
muestras$estacion <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "_")[[1]][2]})
muestras$clase2 <- sapply(as.character(muestras$nombre), function(x){strsplit(x, "")[[1]][1]})
muestras$clase3 <- paste(muestras$clase2, muestras$estacion, sep=".")
muestras

head(tabla)
rownames(tabla) <- muestras$clase3

colors <- colorRampPalette(c("#EACDF6", "#350847"), space="rgb")(40)

plot(annHeatmap2(tabla, col=colors, breaks = 50, 
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), Col = list(dendro = as.dendrogram(col.clus))),
                 legend=3, labels=list(Col=list(nrow=12)),
                 ann=list(Row=list(data=subtabla)),
                 cluster = list(Row=list(cuth=0.25, col=c("seagreen2", "deepskyblue", "coral1")))))
dev.off()


png("figuras/heatmap_class_variables.png", width = 300*10, height = 300*6, units = "px", res=300)
plot(annHeatmap2(tabla, col = colors, breaks = 50,
                 dendrogram = list(Row = list(dendro = as.dendrogram(row.clus)), 
                                   Col = list(dendro = as.dendrogram(col.clus))),
                 legend = 3, labels = list(Col = list(nrow = 12)), 
                 ann = list(Row = list(data = subtabla)),
                 cluster = list(Row = list(cuth = 0.25, col = c("seagreen2", "deepskyblue", "coral1")))))
dev.off()

#### Ejercicio 5. ComplexHeatmap
# Usaremos la matriz de tabla
class(tabla)
dim(tabla)
# 1. Heatmap simple
# Usando paletas predetermindas
Heatmap(tabla, name= "Relative abundance",
        col = rainbow(10),
        column_title = "Class > 1 %")

Heatmap(tabla, name= "Relative abundance",
        col = heat.colors(10),
        column_title = "Class > 1 %")

# 2. Juguemos con los colores
# Generar colores de acuerdo a los valores de la matriz
library(circlize)
min_abu <- min(tabla)
media_abun <- mean(tabla)
max_abun <- max(tabla)
col_fun = colorRamp2(c(min_abu, media_abun, max_abun), c("seagreen2", "white", "deepskyblue"))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %")

# Usando categorias para cada color
discrete_mat <- matrix(sample(1:4, 100, replace = TRUE), 10, 10)
colores <-  structure(1:4, names = c("1", "2", "3", "4")) # black, red, green, blue

Heatmap(discrete_mat, name = "mat", col = colores,
        column_title = "Matrix numerica discreta ")

# 3. Agreguemos anotaciones
variables <- read.delim("tablas/abiotic_variables.txt", header=T, row.names = 1)

# Anotaciones para las columnas
phylum <- read.delim("tablas/ClassPhylum.txt", header=TRUE)
column_ha = HeatmapAnnotation(Phylum = phylum$Phylum)

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha)

# Anotaciones para las filas
muestras
row_ha = rowAnnotation(Clase = muestras$clase)

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = row_ha)

### Cambio de colores especifico

ha= rowAnnotation(Clase = muestras$clase, 
                      col=list(Clase=c("Costa"= "#F2AAB5",
                                       "Someras"= "#F2E9AA",
                                       "Profundas"="#D5A3E8")))
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha)

### Agreguemos mas informacion de las variables
head(variables)
# generemos la paleta de Phenanthrene
min_abu <- min(variables$Phenanthrene)
media_abun <- mean(variables$Phenanthrene)
max_abun <- max(variables$Phenanthrene)
col_phen = colorRamp2(c(min_abu, media_abun, max_abun), c("#F1F1F1","#8B9FC7","#142D4A"))

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                  col=list(Phenanthrene=col_phen))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha,
        right_annotation = ha_right)

# Agreguemos mejor una linea
anno_lines()

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                        col=list(Phenanthrene=col_phen),
                        OrganicMatter = anno_lines(variables$Organic_Matter, 
                                                   gp = gpar(col = 2), add_points = TRUE, 
                                                   pt_gp = gpar(col = 5), pch = 16))


Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        left_annotation = ha,
        right_annotation = ha_right)

## Anotemos grupos de acuerdo a la estructura de nuestro heatmap
ha_left = rowAnnotation(Clase = anno_block(gp = gpar(fill = 2:4),
                                                 labels = c("Someras", "Costa", "Profundas"), 
                                                 labels_gp = gpar(col = "white", fontsize = 10)))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3)

# Mejoremos la apariencia
ha_left = rowAnnotation(Clase = anno_block(gp = gpar(fill = c("#F2E9AA","#F2AAB5","#D5A3E8")),
                                           labels = c("Someras", "Costa", "Profundas"), 
                                           labels_gp = gpar(col = "black", fontsize = 10)))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3)

#### Mejoremos mas la apariencia

column_ha = HeatmapAnnotation(Phylum = phylum$Phylum, 
                              annotation_name_gp = gpar(fontsize = 8))

ha_right= rowAnnotation(Phenanthrene=variables$Phenanthrene,
                        col=list(Phenanthrene=col_phen),
                        OrganicMatter = anno_lines(variables$Organic_Matter, 
                                                   gp = gpar(col = 2), add_points = TRUE, 
                                                   pt_gp = gpar(col = 5), pch = 16),
                        annotation_name_rot = 45, 
                        annotation_name_gp = gpar(fontsize = 8))

Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3,
        show_row_dend = FALSE, # quitar el dendograma de las filas
        row_names_gp = gpar(fontsize = 8), # Cambiar el tamaño de letra de las filas
        column_names_gp = gpar(fontsize = 8, fontface="italic"), # Cambiar el tamaño de letra de las columnas
        column_names_rot = 45 # Cambiar la orientacion del texto en columnas
        )

png("figuras/heatmap_ComplexHeatmap.png", width = 9*300 , height = 6*300, units = "px", bg = "white", res = 300)
Heatmap(tabla, name= "Relative abundance",
        col = col_fun,
        column_title = "Class > 1 %",
        top_annotation = column_ha,
        right_annotation = ha_right,
        left_annotation = ha_left,
        row_km = 3,
        show_row_dend = FALSE, # quitar el dendograma de las filas
        row_names_gp = gpar(fontsize = 8), # Cambiar el tamaño de letra de las filas
        column_names_gp = gpar(fontsize = 8, fontface="italic"), # Cambiar el tamaño de letra de las columnas
        column_names_rot = 45 # Cambiar la orientacion del texto en columnas
)
dev.off()


